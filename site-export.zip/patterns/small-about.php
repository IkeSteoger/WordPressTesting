<?php
/**
 * Title: Small About Text 
 * Slug: vetro/small-about
 * Inserter: no
 */
?>

<!-- wp:paragraph {"style":{"typography":{"lineHeight":"1.3","fontSize":"0.8rem","fontStyle":"normal","fontWeight":"500"}}} -->
<p style="font-size:0.8rem;font-style:normal;font-weight:500;line-height:1.3"><?php echo esc_html__( 'We\'re open for new collaborations.', 'vetro' ); ?><br><?php echo esc_html__( 'News to be updated weekly.', 'vetro' ); ?></p>
<!-- /wp:paragraph -->